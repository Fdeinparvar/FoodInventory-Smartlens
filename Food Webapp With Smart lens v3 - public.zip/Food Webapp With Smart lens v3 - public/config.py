# Configuration file for API keys
# Replace 'your-api-key-here' with your actual Anthropic API key
# Get your API key from: https://console.anthropic.com/
# Your API key should start with 'sk-ant-'

ANTHROPIC_API_KEY = "sk-ant-api03-..."

# Example (replace with your actual key):
# ANTHROPIC_API_KEY = "sk-ant-api03-..." 